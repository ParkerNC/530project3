float dotprod(float x[], float y[], int n)
{
}
